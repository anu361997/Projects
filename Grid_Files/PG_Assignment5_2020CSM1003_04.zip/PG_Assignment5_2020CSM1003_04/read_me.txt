#Lab Assignment 5
#Grid Files

Project Team:

1. Akshay Kumar Dixit: 2020CSM1003
2. Anamika	     : 2020CSM1004

Implementation Details:

The project implementation contains 3 files: 

1. dataset_gen.py
2. grid_files.py
3. naive_range_query.py


dataset_gen.py generates a file named "DataSet.txt" containing the user defined number of records. The same file is used in the other files.
grid_files.py contains the range_query function in itself
naive_range_query.py implements naive algorithm for range_query which is run on the dataset genrated by dataset_gen.py
